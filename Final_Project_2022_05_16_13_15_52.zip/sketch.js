//may not work on safari
// Declare a "SerialPort" object
var serial;
let key02;
let key04;
let key06;
let key08;
let key10;
let key12;

// fill in the name of your serial port here:
//copy this from the serial control app
var portName = "COM3";

//this array will hold transmitted data
var inMessage = [0, 0, 0, 0, 0];

function preload() {
  soundFormats("mp3");
  key02 = loadSound("key02.mp3");
  key04 = loadSound("key04.mp3");
  key06 = loadSound("key06.mp3");
  key08 = loadSound("key08.mp3");
  key10 = loadSound("key10.mp3");
  key12 = loadSound("key12.mp3");
}

function setup() {
  createCanvas(400, 400);

  // make an instance of the SerialPort object
  serial = new p5.SerialPort();

  // Get a list the ports available
  // You should have a callback defined to see the results. See gotList, below:
  serial.list();

  // Assuming our Arduino is connected,  open the connection to it
  serial.open(portName);

  // When you get a list of serial ports that are available
  serial.on("list", gotList);

  // When you some data from the serial port
  serial.on("data", gotData);
}

// Got the list of ports
function gotList(thelist) {
  // theList is an array of their names
  for (var i = 0; i < thelist.length; i++) {
    // Display in the console
    console.log(i + " " + thelist[i]);
  }
}

// Called when there is data available from the serial port
function gotData() {
  var currentString = serial.readLine(); // read the incoming data
  trim(currentString); // trim off trailing whitespace
  if (!currentString) return; // if the incoming string is empty, do no more
  console.log(currentString);
  inMessage = split(currentString, "&"); // save the currentString to use for the text
}

function draw() {
  background(225);

  if (inMessage[0] > 50){
    if (!key02.isPlaying()) {
      // play sound
      key02.play();
    }
  }
if (inMessage[0] < 100) {
  //stop sound
  if (!key02.isPlaying()) {
    key02.stop();
  }
}
if (inMessage[1] > 50) {
  //play sound
  if (!key04.isPlaying()) {
    key04.play();
  }
}
if (inMessage[1] < 100) {
  //stop sound
  if (!key04.isPlaying()) {
    key04.stop();
  }
}
if (inMessage[2] > 50) {
  //play sound
  if (!key06.isPlaying()) {
    key06.play();
  }
}
if (inMessage[2] < 100) {
  //stop sound
  if (!key06.isPlaying()) {
    key06.stop();
  }
}
if (inMessage[3] > 50) {
  //play sound
  if (!key08.isPlaying()) {
    key08.play();
  }
}
if (inMessage[3] < 100) {
  //stop sound
  if (!key08.isPlaying()) {
    key08.stop();
  }
}
if (inMessage[4] > 50) {
  //play sound
  if (!key10.isPlaying()) {
    key10.play();
  }
}
if (inMessage[4] < 100) {
  //stop sound
  if (!key10.isPlaying()) {
    key10.stop();
  }
}
if (inMessage[5] > 50) {
  //play sound
  if (!key12.isPlaying()) {
    key12.play();
  }
}
if (inMessage[5] < 100) {
  //stop sound
  if (!key12.isPlaying()) {
    key012.stop();
  }
}
}